var hierarchy =
[
    [ "Flow", "classFlow.html", [
      [ "Exp", "classExp.html", null ],
      [ "Logistic", "classLogistic.html", null ]
    ] ],
    [ "Model", "classModel.html", null ],
    [ "System", "classSystem.html", null ]
];