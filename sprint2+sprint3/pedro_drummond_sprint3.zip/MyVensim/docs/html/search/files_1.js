var searchData=
[
  ['exponencial_2eh_60',['exponencial.h',['../exponencial_8h.html',1,'']]]
];
