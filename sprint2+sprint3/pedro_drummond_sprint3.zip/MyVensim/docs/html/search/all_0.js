var searchData=
[
  ['add_0',['add',['../classModel.html#a302d4ed93c6e6f9a0f728e021a91f821',1,'Model::add(System *system)'],['../classModel.html#ab69613bde0ace81c92bbf519660ccb2c',1,'Model::add(Flow *flow)']]]
];
