var searchData=
[
  ['logistic_20',['Logistic',['../classLogistic.html',1,'Logistic'],['../classLogistic.html#a9abb9707da1385753650e246b18fd21c',1,'Logistic::Logistic()']]],
  ['logistic_2eh_21',['logistic.h',['../logistic_8h.html',1,'']]],
  ['logistic_5ffuncional_5ftest_22',['logistic_funcional_test',['../functional__tests_8h.html#af5f23b6dc5f600222016adb2e24f32b6',1,'functional_tests.h']]]
];
