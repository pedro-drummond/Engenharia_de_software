var searchData=
[
  ['logistic_84',['Logistic',['../classLogistic.html#a9abb9707da1385753650e246b18fd21c',1,'Logistic']]],
  ['logistic_5ffuncional_5ftest_85',['logistic_funcional_test',['../functional__tests_8h.html#af5f23b6dc5f600222016adb2e24f32b6',1,'functional_tests.h']]]
];
