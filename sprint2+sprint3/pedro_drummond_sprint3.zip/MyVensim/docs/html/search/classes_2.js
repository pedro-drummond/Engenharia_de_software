var searchData=
[
  ['logistic_56',['Logistic',['../classLogistic.html',1,'']]]
];
