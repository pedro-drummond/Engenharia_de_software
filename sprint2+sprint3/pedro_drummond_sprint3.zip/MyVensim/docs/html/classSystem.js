var classSystem =
[
    [ "System", "classSystem.html#ae317936c9bcf1374d61745572e0f2f8a", null ],
    [ "System", "classSystem.html#a4f45df63c90a82f1c915114ac1d6e8a1", null ],
    [ "~System", "classSystem.html#a3be70bb338e3f062f821173fd15680d0", null ],
    [ "System", "classSystem.html#a603517c422f63503086dc7935e2398f3", null ],
    [ "getName", "classSystem.html#a47ece132a04247cd74aea11537830bd4", null ],
    [ "getValue", "classSystem.html#aa7d17369d1034e7d8643a63f69d1901d", null ],
    [ "operator=", "classSystem.html#a7b1b2bc21110d1b7ad7524a529e5ffb1", null ],
    [ "setName", "classSystem.html#a5e44855b2f6e60b599cda9d00a611ff6", null ],
    [ "setValue", "classSystem.html#aaa7fc2020cf29315b82f4fb444c45068", null ],
    [ "name", "classSystem.html#a29fe2868c0d56fdebc67f1bef5d5cca3", null ],
    [ "value", "classSystem.html#a879687b1125ef20757c2a61345fedd00", null ]
];