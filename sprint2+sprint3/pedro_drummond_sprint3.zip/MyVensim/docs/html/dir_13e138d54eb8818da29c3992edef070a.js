var dir_13e138d54eb8818da29c3992edef070a =
[
    [ "exponencial.h", "exponencial_8h.html", [
      [ "Exp", "classExp.html", "classExp" ]
    ] ],
    [ "functional_tests.h", "functional__tests_8h.html", "functional__tests_8h" ],
    [ "logistic.h", "logistic_8h.html", [
      [ "Logistic", "classLogistic.html", "classLogistic" ]
    ] ],
    [ "main.cpp", "test_2main_8cpp.html", "test_2main_8cpp" ]
];