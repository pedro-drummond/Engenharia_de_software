var classHandle =
[
    [ "Handle", "classHandle.html#a6a72028918adf79c0ff8d9996e5e4107", null ],
    [ "~Handle", "classHandle.html#addd59fdf43baa517a06d44e1125b5ab1", null ],
    [ "Handle", "classHandle.html#af304e7014a2e600e235140d246783f85", null ],
    [ "operator=", "classHandle.html#a06418155d929707d0a95e27efb8f3b82", null ],
    [ "pImpl_", "classHandle.html#a16021e57596d7369dfa1a9fadc35c06f", null ]
];