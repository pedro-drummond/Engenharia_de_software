var classSystem =
[
    [ "~System", "classSystem.html#a2fc0f34023977cab9b628aa9f734d88c", null ],
    [ "getName", "classSystem.html#ab4f23c21832d6bbef462a5a20b296912", null ],
    [ "getValue", "classSystem.html#a41b673faa6c199eb8e4f204639fab4f2", null ],
    [ "setName", "classSystem.html#a7d66d817b6253d96621adc1b6e9dbe40", null ],
    [ "setValue", "classSystem.html#a624bcfec7ae7d474eeaba0e2315f6a81", null ]
];