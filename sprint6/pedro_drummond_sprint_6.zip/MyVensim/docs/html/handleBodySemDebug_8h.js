var handleBodySemDebug_8h =
[
    [ "Handle", "classHandle.html", "classHandle" ],
    [ "Body", "classBody.html", "classBody" ],
    [ "numBodyCreated", "handleBodySemDebug_8h.html#ac1322042429ed9724fbef55908244f3b", null ],
    [ "numBodyDeleted", "handleBodySemDebug_8h.html#aba38ebae7f83ef57afab8c447dddb6cf", null ],
    [ "numHandleCreated", "handleBodySemDebug_8h.html#aac78cb29dfe4a565da68073b0beebf2f", null ],
    [ "numHandleDeleted", "handleBodySemDebug_8h.html#a01128a06118f949a0b24a3d080f515fd", null ]
];