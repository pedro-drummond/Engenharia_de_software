var classBaseSystem =
[
    [ "getName", "classBaseSystem.html#a277f1b0732a052b0676dbdf2221bce3e", null ],
    [ "getValue", "classBaseSystem.html#a7fc19f387c3c8b00a72b62729cd47229", null ],
    [ "setName", "classBaseSystem.html#ac6e282da4730e04a0968c88ae150f0fa", null ],
    [ "setValue", "classBaseSystem.html#a6df3b222dad8c7a0d5dbe85df6d95af6", null ],
    [ "name", "classBaseSystem.html#a7489afd858f73f45d8b27ed7b5b0af3c", null ],
    [ "value", "classBaseSystem.html#a55f2c5e8228692e9aeb1697adacc3068", null ]
];