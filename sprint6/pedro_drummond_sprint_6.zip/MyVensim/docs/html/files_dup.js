var files_dup =
[
    [ "doc_pages", "dir_e3544fb0b774253c3e72718d4f8fa5ea.html", null ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "test", "dir_13e138d54eb8818da29c3992edef070a.html", "dir_13e138d54eb8818da29c3992edef070a" ],
    [ "main.cpp", "main_8cpp.html", null ]
];