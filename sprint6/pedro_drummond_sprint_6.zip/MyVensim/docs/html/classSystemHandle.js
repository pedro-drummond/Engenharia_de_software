var classSystemHandle =
[
    [ "SystemHandle", "classSystemHandle.html#a643b5fead6aca3df6ff28ee359d9e63b", null ],
    [ "getName", "classSystemHandle.html#ae0e8c19df92e41d60f2156562fd2bd52", null ],
    [ "getValue", "classSystemHandle.html#aeb69190853dc47d4c73ccd3928bfc3a1", null ],
    [ "setName", "classSystemHandle.html#aa8da8c60723c4a7dd3457419a2527c4f", null ],
    [ "setValue", "classSystemHandle.html#aa7206ceb4d5ceaf67271edb1b12e135d", null ]
];