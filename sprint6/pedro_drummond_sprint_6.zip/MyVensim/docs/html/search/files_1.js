var searchData=
[
  ['exponencial_2eh_147',['exponencial.h',['../exponencial_8h.html',1,'']]]
];
