var searchData=
[
  ['pagina_20principal_20da_20api_64',['Pagina principal da API',['../index.html',1,'']]],
  ['pimpl_5f_65',['pImpl_',['../classHandle.html#a16021e57596d7369dfa1a9fadc35c06f',1,'Handle']]]
];
