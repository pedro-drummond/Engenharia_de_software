var searchData=
[
  ['logistic_140',['Logistic',['../classLogistic.html',1,'']]]
];
