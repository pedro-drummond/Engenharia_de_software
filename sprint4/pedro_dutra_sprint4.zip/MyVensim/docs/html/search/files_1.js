var searchData=
[
  ['exponencial_2eh_114',['exponencial.h',['../exponencial_8h.html',1,'']]]
];
