var searchData=
[
  ['logistic_109',['Logistic',['../classLogistic.html',1,'']]]
];
