var indexSectionsWithContent =
{
  0: "abcdefglmnoprstuv~",
  1: "beflms",
  2: "ceflmsu",
  3: "abcefglmorsu~",
  4: "bdefnostv",
  5: "fs",
  6: "cp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Pages"
};

