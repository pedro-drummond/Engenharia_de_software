#ifndef unit_system_h
#define unit_system_h

void unit_system_constructor(void);
void unit_system_setValue(void);
void unit_system_setName(void);
void unit_system_getValue(void);
void unit_system_getName(void);


#endif /* unit_system_h */