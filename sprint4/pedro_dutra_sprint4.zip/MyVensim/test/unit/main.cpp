#include "unit_flow.h"
#include "unit_system.h"
#include "unit_model.h"
#include "unit_tests.h"
#include <iostream>
using namespace std;

int main(){

    unit_tests();

    return 0;
}