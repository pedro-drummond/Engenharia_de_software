#ifndef unit_flow_h
#define unit_flow_h

void unit_flow_constructor(void);
void unit_flow_setSource(void);
void unit_flow_setTarget(void);
void unit_flow_getSource(void);
void unit_flow_getTarget(void);
void unit_flow(void);

#endif /* unit_flow_h */