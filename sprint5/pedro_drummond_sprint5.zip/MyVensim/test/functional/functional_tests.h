//min 47

#ifndef EXP_TEST_H
#define EXP_TEST_H


using namespace std;
/// @brief test for the exponential function
void exponential_funcional_test();
/// @brief test for the logistic function
void logistic_funcional_test();

/// @brief test for the exponential function in a system
void exponential_system_funcional_test();

#endif // EXP_TEST_H
