#include "functional_tests.h"
using namespace std;
/// @brief test for the exponential and logistic function
/// @return 
int main(){
    exponential_funcional_test();
    logistic_funcional_test();
    exponential_system_funcional_test();
    return 0;
}