var searchData=
[
  ['exponencial_2eh_119',['exponencial.h',['../exponencial_8h.html',1,'']]]
];
