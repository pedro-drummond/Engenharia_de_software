var searchData=
[
  ['logistic_162',['Logistic',['../classLogistic.html#a9abb9707da1385753650e246b18fd21c',1,'Logistic']]],
  ['logistic_5ffuncional_5ftest_163',['logistic_funcional_test',['../functional__tests_8cpp.html#af5f23b6dc5f600222016adb2e24f32b6',1,'logistic_funcional_test():&#160;functional_tests.cpp'],['../functional__tests_8h.html#af5f23b6dc5f600222016adb2e24f32b6',1,'logistic_funcional_test():&#160;functional_tests.cpp']]]
];
