var searchData=
[
  ['models_212',['models',['../classBaseModel.html#a378f57d28d2b12200e2bcb3ed0423885',1,'BaseModel']]]
];
