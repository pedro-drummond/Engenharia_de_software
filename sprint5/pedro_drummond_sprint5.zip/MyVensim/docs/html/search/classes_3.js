var searchData=
[
  ['logistic_114',['Logistic',['../classLogistic.html',1,'']]]
];
