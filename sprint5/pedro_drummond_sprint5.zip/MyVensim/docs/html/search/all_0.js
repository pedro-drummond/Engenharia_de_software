var searchData=
[
  ['add_0',['add',['../classModel.html#afde6c25ab942f2eec7aedeaf8eec53fd',1,'Model::add(System *system)=0'],['../classModel.html#ab7df81041f62f049cfc6e4d50dcaf721',1,'Model::add(Flow *flow)=0'],['../classModel.html#a121223748aeae1aebdbcc3374a729c1d',1,'Model::add(Model *model)=0'],['../classBaseModel.html#a2ff1069e5da820fc12b2405f7ba217c3',1,'BaseModel::add(Model *model)'],['../classBaseModel.html#af4f00f31e13f60958f911e78d4a117d9',1,'BaseModel::add(System *system)'],['../classBaseModel.html#a28f04a6623d0de5c560eff73c1024a86',1,'BaseModel::add(Flow *flow)']]]
];
