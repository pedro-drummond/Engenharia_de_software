var searchData=
[
  ['name_213',['name',['../classBaseModel.html#abbc1b3452e3fa6149842cc9b9eb2d1f2',1,'BaseModel::name()'],['../classBaseSystem.html#a7489afd858f73f45d8b27ed7b5b0af3c',1,'BaseSystem::name()']]]
];
