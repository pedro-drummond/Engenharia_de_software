var structModelIterator =
[
    [ "begin", "structModelIterator.html#a13f74a9e7874cedbc5c548af79763aa1", null ],
    [ "end", "structModelIterator.html#a7ee6a67b0ae68c244dfeee5304f6fda3", null ]
];