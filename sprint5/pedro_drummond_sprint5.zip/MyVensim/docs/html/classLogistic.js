var classLogistic =
[
    [ "Logistic", "classLogistic.html#a9abb9707da1385753650e246b18fd21c", null ],
    [ "~Logistic", "classLogistic.html#a788085f68f67d411f9ef1bd1b9de7fb8", null ],
    [ "run", "classLogistic.html#af6f99f0b3655a4f2066617564935ff24", null ]
];